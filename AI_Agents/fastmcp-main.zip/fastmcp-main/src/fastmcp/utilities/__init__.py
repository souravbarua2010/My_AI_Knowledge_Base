"""FastMCP utility modules."""
