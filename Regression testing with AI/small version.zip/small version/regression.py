"""AI-first regression runner.

1. Compares baseline and current screenshots.
2. Sends baseline/current/diff to the local VLM.
3. Asks the local LLM to write a QA report.
4. Saves a Markdown report.

Usage:
  uv run python regression.py
"""

import argparse
import json
from datetime import datetime
from pathlib import Path

import numpy as np
from PIL import Image, ImageChops

from ai_client import analyze_regression, write_report


def make_diff(baseline_path: Path, current_path: Path, diff_path: Path) -> float:
    baseline = Image.open(baseline_path).convert("RGB")
    current = Image.open(current_path).convert("RGB")
    if baseline.size != current.size:
        raise SystemExit(f"Screenshot sizes differ: {baseline.size} vs {current.size}")

    difference = ImageChops.difference(baseline, current)
    pixels = np.asarray(difference)
    changed = pixels.max(axis=2) > 8
    changed_percent = float(changed.mean())

    image = np.full((*changed.shape, 3), 255, dtype=np.uint8)
    image[changed] = [220, 38, 38]
    Image.fromarray(image).save(diff_path)
    return changed_percent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--threshold", type=float, default=0.001)
    args = parser.parse_args()

    baseline = Path("screenshots/baseline.png")
    current = Path("screenshots/current.png")
    diff = Path("screenshots/diff.png")

    if not baseline.exists() or not current.exists():
        raise SystemExit("Run capture.py for both baseline and current screenshots first.")

    changed_percent = make_diff(baseline, current, diff)
    print(f"Pixel change: {changed_percent:.4%}")

    if changed_percent <= args.threshold:
        analysis = {
            "is_regression": False,
            "severity": "none",
            "what_changed": "No meaningful pixel difference detected.",
            "why_it_matters": "The current screenshot matches the approved baseline.",
            "recommended_action": "approve_baseline",
        }
    else:
        print("Asking local VLM to analyze the visual regression...")
        analysis = analyze_regression(baseline, current, diff, changed_percent)

    print("Asking local LLM to write the QA report...")
    report = write_report(analysis, changed_percent)

    reports = Path("reports")
    reports.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    report_path = reports / f"regression-{timestamp}.md"
    report_path.write_text(
        f"# AI Regression Report\n\n"
        f"**Changed pixels:** {changed_percent:.4%}\n\n"
        f"## Vision model analysis\n\n"
        f"```json\n{json.dumps(analysis, indent=2)}\n```\n\n"
        f"## QA report\n\n{report}\n",
        encoding="utf-8",
    )

    print(f"AI decision: {analysis}")
    print(f"Report saved: {report_path}")


if __name__ == "__main__":
    main()
