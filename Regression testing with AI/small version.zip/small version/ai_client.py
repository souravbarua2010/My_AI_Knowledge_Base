"""Local AI client for Foundry Local.

The VLM explains visual regressions.
The LLM converts technical findings into a concise QA report.
"""

import base64
import json
import os
from pathlib import Path

from openai import OpenAI

VISION_MODEL = os.getenv("VISION_MODEL", "qwen3-vl-2b-instruct")
TEXT_MODEL = os.getenv("TEXT_MODEL", "qwen2.5-0.5b")


def _client() -> OpenAI:
    endpoint = os.getenv("FOUNDRY_ENDPOINT")
    if not endpoint:
        from foundry_local import FoundryLocalManager

        manager = FoundryLocalManager(VISION_MODEL)
        endpoint = manager.endpoint
    return OpenAI(base_url=endpoint, api_key="not-needed")


def _image(path: str | Path) -> dict:
    encoded = base64.b64encode(Path(path).read_bytes()).decode()
    return {
        "type": "image_url",
        "image_url": {"url": f"data:image/png;base64,{encoded}"},
    }


def analyze_regression(
    baseline: str | Path,
    current: str | Path,
    diff: str | Path,
    changed_percent: float,
) -> dict:
    """Ask the VLM whether the visual difference is a meaningful regression."""
    client = _client()

    response = client.chat.completions.create(
        model=VISION_MODEL,
        temperature=0,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a senior QA engineer. Compare baseline, current, and diff "
                    "screenshots. Identify meaningful user-visible regressions. "
                    "Respond with JSON only in this exact shape: "
                    '{"is_regression": true/false, "severity": "low/medium/high/critical/none", '
                    '"what_changed": "short description", '
                    '"why_it_matters": "short explanation", '
                    '"recommended_action": "fix_ui/approve_baseline/investigate"}'
                ),
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"Changed pixel ratio: {changed_percent:.4%}. "
                        "Image 1 is baseline, image 2 is current, image 3 is diff.",
                    },
                    _image(baseline),
                    _image(current),
                    _image(diff),
                ],
            },
        ],
    )

    raw = (response.choices[0].message.content or "{}").strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:]
    return json.loads(raw)


def write_report(analysis: dict, changed_percent: float) -> str:
    """Ask the LLM to turn the VLM finding into a short QA report."""
    client = _client()
    response = client.chat.completions.create(
        model=TEXT_MODEL,
        temperature=0.2,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a QA report writer. Write a concise regression report "
                    "in under 120 words. Include status, what changed, impact, and next action."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Changed pixels: {changed_percent:.4%}
"
                    f"Vision analysis JSON:
{json.dumps(analysis, indent=2)}"
                ),
            },
        ],
    )
    return response.choices[0].message.content or ""
