# Simple AI-First Regression Testing

This is a minimal but AI-centered regression testing project. It uses local models through Foundry Local:

- `qwen3-vl-2b-instruct` looks at baseline, current, and diff screenshots and decides whether the change is a meaningful regression.
- `qwen2.5-0.5b` converts the VLM finding into a concise QA report.

Playwright only captures evidence. The image comparison detects that pixels changed. The AI explains whether the change matters.

## Setup

```bash
uv sync
uv run playwright install chromium
cp .env.example .env
```

Ensure Foundry Local is running and both models are downloaded.

## 1. Start demo website

```bash
uv run uvicorn demo:app --host 127.0.0.1 --port 8001 --reload
```

## 2. Capture baseline

```bash
uv run python capture.py --name baseline --variant stable
```

## 3. Capture changed version

```bash
uv run python capture.py --name current --variant changed
```

## 4. Run AI regression analysis

```bash
uv run python regression.py
```

The command will:

1. Create `screenshots/diff.png`.
2. Send baseline, current, and diff images to the VLM.
3. Ask the VLM whether this is a regression.
4. Ask the LLM to write a QA report.
5. Save a Markdown report in `reports/`.

## Example AI output

```json
{
  "is_regression": true,
  "severity": "medium",
  "what_changed": "The primary call-to-action button changed text and color.",
  "why_it_matters": "The CTA no longer matches the approved design and may affect user recognition.",
  "recommended_action": "investigate"
}
```

## Tests

```bash
uv run pytest
```
