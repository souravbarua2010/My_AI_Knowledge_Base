"""Capture a demo-site screenshot.

  uv run python capture.py --name baseline --variant stable
  uv run python capture.py --name current --variant changed
"""

import argparse
from pathlib import Path

from dotenv import load_dotenv
from os import getenv
from playwright.sync_api import sync_playwright

load_dotenv()
BASE_URL = getenv("DEMO_URL", "http://127.0.0.1:8001")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True, choices=["baseline", "current"])
    parser.add_argument("--variant", default="stable", choices=["stable", "changed"])
    args = parser.parse_args()

    output = Path("screenshots") / f"{args.name}.png"
    output.parent.mkdir(exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        page.goto(f"{BASE_URL}/?variant={args.variant}", wait_until="networkidle")
        page.screenshot(path=str(output), full_page=True)
        browser.close()

    print(f"Saved: {output}")


if __name__ == "__main__":
    main()
