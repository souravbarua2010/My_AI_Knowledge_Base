from fastapi.testclient import TestClient

from demo import app


def test_changed_variant_changes_button() -> None:
    with TestClient(app) as client:
        stable = client.get("/?variant=stable").text
        changed = client.get("/?variant=changed").text
    assert "Get started" in stable
    assert "Start Now!" in changed
