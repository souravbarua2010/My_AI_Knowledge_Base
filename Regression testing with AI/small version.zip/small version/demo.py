"""Tiny demo website with stable and intentionally changed variants."""

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

app = FastAPI()
templates = Jinja2Templates(directory=Path(__file__).parent / "templates")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    changed = request.query_params.get("variant") == "changed"
    return templates.TemplateResponse(
        request=request,
        name="home.html",
        context={
            "changed": changed,
            "headline": "Welcome to Demo App",
            "button_text": "Get started" if not changed else "Start Now!",
        },
    )
